# MOBILE WEB SERVICE MODULE — MEDIA

Paket file media untuk peserta, sesuai dengan bagian **FILE MEDIA** pada
`03_Mobile_Web_Service_Module_ID.md`.

## Isi paket

```
wireframes/            5 wireframe low-fidelity (480px, mobile) — referensi layout & UI
  01_home.svg
  02_discover.svg
  03_article_detail.svg
  04_bookmark.svg
  05_settings.svg

starter-react-vite/    Starter project React + Vite (opsional, pilih salah satu framework)
starter-vue-vite/      Starter project Vue + Vite (opsional, pilih salah satu framework)

offline/
  game.html            Halaman offline (ditampilkan saat koneksi internet terputus)
```

## Catatan penggunaan

- **Wireframes** hanya panduan tata letak (header fixed atas, content scrollable,
  nav bar fixed bawah dengan 4 tombol: Home, Discover, Bookmark, Settings).
  Styling/desain visual akhir bebas ditentukan peserta.
- **Starter React/Vue** bersifat opsional dan berupa *skeleton*, bukan solusi
  jadi — beberapa bagian ditandai `TODO` dan wajib dilengkapi peserta. Peserta
  juga boleh membangun dari nol dengan Vanilla JavaScript sesuai instruksi modul.
  Pilih **satu** framework saja.
- **`offline/game.html`** adalah file HTML mandiri (tanpa dependency eksternal)
  yang ditampilkan saat pengguna kehilangan koneksi internet. Peserta dapat
  menyalin file ini ke folder public/static proyek masing-masing dan
  mengarahkannya sesuai mekanisme deteksi offline yang mereka bangun
  (contoh sudah disediakan di `main.jsx` / `main.js` pada masing-masing starter).
- Ikon PWA pada `public/icons/` di kedua starter adalah **placeholder** —
  peserta perlu menggantinya dengan ikon final sebelum submit jika diperlukan.

## Konfigurasi API

Kedua starter sudah mengonfigurasi API base URL di satu tempat (`.env` →
`VITE_API_URL`), sesuai instruksi modul:

```
http://api-mobile-service.lksn.id
```

Jangan hardcode URL ini di file lain — semua pemanggilan API harus melalui
`src/api/client.js`.
