<script setup>
import { onMounted, onUnmounted, ref, watch } from 'vue'
import Header from './components/Header.vue'
import BottomNav from './components/BottomNav.vue'
import Home from './pages/Home.vue'
import Discover from './pages/Discover.vue'
import ArticleDetail from './pages/ArticleDetail.vue'
import Bookmark from './pages/Bookmark.vue'
import Settings from './pages/Settings.vue'

const BOOKMARK_KEY = 'apakabar_bookmarks'
const TITLES = {
  home: 'ApaKabar',
  discover: 'Discover',
  bookmark: 'Bookmark',
  settings: 'Settings',
}

// NOTE: Ini adalah contoh routing sederhana berbasis state (tanpa library router)
// agar starter tetap ringan. Peserta bebas mengganti dengan vue-router
// atau pendekatan lain sesuai preferensi masing-masing.
const activeTab = ref('home')
const activeSlug = ref(null)
const isOffline = ref(!navigator.onLine)
const bookmarks = ref(JSON.parse(localStorage.getItem(BOOKMARK_KEY) || '[]'))

watch(bookmarks, (value) => {
  localStorage.setItem(BOOKMARK_KEY, JSON.stringify(value))
}, { deep: true })

function goOffline() { isOffline.value = true }
function goOnline() { isOffline.value = false }

onMounted(() => {
  window.addEventListener('offline', goOffline)
  window.addEventListener('online', goOnline)
})
onUnmounted(() => {
  window.removeEventListener('offline', goOffline)
  window.removeEventListener('online', goOnline)
})

function openArticle(slug) {
  activeSlug.value = slug
}
function closeArticle() {
  activeSlug.value = null
}
function changeTab(tab) {
  activeSlug.value = null
  activeTab.value = tab
}
function toggleBookmark(post) {
  bookmarks.value = bookmarks.value.some((p) => p.slug === post.slug)
    ? bookmarks.value.filter((p) => p.slug !== post.slug)
    : [...bookmarks.value, post]
}
function isBookmarked(slug) {
  return bookmarks.value.some((p) => p.slug === slug)
}
</script>

<template>
  <!-- TODO: peserta dapat mengganti ini dengan <iframe src="/offline/game.html" />
       atau redirect penuh ke game.html sesuai kebutuhan build tool masing-masing. -->
  <div v-if="isOffline" class="offline-screen">
    <p>Anda sedang offline. Silakan buka <code>offline/game.html</code>.</p>
  </div>

  <div v-else-if="activeSlug" class="app-shell">
    <Header title="Detail Artikel" :on-back="closeArticle" />
    <main class="app-content">
      <ArticleDetail
        :slug="activeSlug"
        :is-bookmarked="isBookmarked(activeSlug)"
        @open-article="openArticle"
        @toggle-bookmark="toggleBookmark"
      />
    </main>
    <BottomNav :active="activeTab" @change="changeTab" />
  </div>

  <div v-else class="app-shell">
    <Header :title="TITLES[activeTab]" />
    <main class="app-content">
      <Home v-if="activeTab === 'home'" @open-article="openArticle" />
      <Discover v-else-if="activeTab === 'discover'" @open-article="openArticle" />
      <Bookmark
        v-else-if="activeTab === 'bookmark'"
        :bookmarks="bookmarks"
        @open-article="openArticle"
        @toggle-bookmark="toggleBookmark"
      />
      <Settings v-else-if="activeTab === 'settings'" />
    </main>
    <BottomNav :active="activeTab" @change="(tab) => (activeTab = tab)" />
  </div>
</template>
