<script setup>
import { onMounted, onUnmounted, ref, watch } from 'vue'
import { getCategories, getPosts } from '../api/client'
import { useDebounce } from '../composables/useDebounce'

defineEmits(['open-article'])

const search = ref('')
const debouncedSearch = useDebounce(search, 600)

const categories = ref([])
const selectedCategories = ref([])

const posts = ref([])
const page = ref(1)
const hasMore = ref(true)
const loading = ref(false)

const sentinel = ref(null)
let observer = null

onMounted(async () => {
  const res = await getCategories()
  categories.value = res.data ?? res

  observer = new IntersectionObserver(
    (entries) => {
      const [entry] = entries
      if (entry.isIntersecting && hasMore.value && !loading.value) {
        page.value += 1
      }
    },
    { rootMargin: '200px' },
  )
  if (sentinel.value) observer.observe(sentinel.value)

  fetchPosts()
})

onUnmounted(() => observer?.disconnect())

// Reset ke halaman 1 setiap kali search/filter berubah
watch([debouncedSearch, selectedCategories], () => {
  page.value = 1
  posts.value = []
  hasMore.value = true
  fetchPosts()
}, { deep: true })

watch(page, (p) => {
  if (p > 1) fetchPosts()
})

async function fetchPosts() {
  loading.value = true
  try {
    const res = await getPosts({
      page: page.value,
      per_page: 10,
      search: debouncedSearch.value,
      category: selectedCategories.value.join(','),
    })
    const newPosts = res.data ?? res
    posts.value = page.value === 1 ? newPosts : [...posts.value, ...newPosts]
    hasMore.value = newPosts.length > 0 && (res.meta?.has_more ?? newPosts.length === 10)
  } finally {
    loading.value = false
  }
}

function toggleCategory(slug) {
  selectedCategories.value = selectedCategories.value.includes(slug)
    ? selectedCategories.value.filter((c) => c !== slug)
    : [...selectedCategories.value, slug]
}
</script>

<template>
  <div class="page">
    <div class="search-bar">
      <input type="search" placeholder="Cari artikel..." v-model="search" />
    </div>

    <div class="category-chips">
      <button
        class="chip"
        :class="{ 'chip--active': selectedCategories.length === 0 }"
        @click="selectedCategories = []"
      >
        Semua
      </button>
      <button
        v-for="cat in categories"
        :key="cat.slug"
        class="chip"
        :class="{ 'chip--active': selectedCategories.includes(cat.slug) }"
        @click="toggleCategory(cat.slug)"
      >
        {{ cat.name }}
      </button>
    </div>

    <div class="article-grid">
      <button
        v-for="post in posts"
        :key="post.slug"
        class="article-card"
        @click="$emit('open-article', post.slug)"
      >
        <div class="thumb" />
        <span class="category-tag">{{ post.category?.name }}</span>
        <p class="card-title">{{ post.title }}</p>
      </button>
    </div>

    <p v-if="loading" class="muted center">Memuat...</p>
    <p v-if="!hasMore && posts.length > 0" class="muted center">
      Semua artikel sudah ditampilkan.
    </p>

    <!-- Sentinel untuk infinite scroll -->
    <div ref="sentinel" style="height: 1px"></div>
  </div>
</template>
