<script setup>
import { ref, watch } from 'vue'
import { getPostBySlug, getPosts } from '../api/client'

const props = defineProps({
  slug: { type: String, required: true },
  isBookmarked: { type: Boolean, required: true },
})
const emit = defineEmits(['open-article', 'toggle-bookmark'])

const article = ref(null)
const related = ref([])

async function load(slug) {
  article.value = null
  const res = await getPostBySlug(slug)
  const data = res.data ?? res
  article.value = data

  const relRes = await getPosts({ category: data.category?.slug, per_page: 4 })
  related.value = (relRes.data ?? relRes).filter((p) => p.slug !== slug).slice(0, 3)
}

watch(() => props.slug, load, { immediate: true })
</script>

<template>
  <div class="page">
    <p v-if="!article" class="muted center">Memuat artikel...</p>

    <template v-else>
      <div class="cover-image" />

      <div class="article-body">
        <div class="article-top-row">
          <span class="category-tag">{{ article.category?.name }}</span>
          <button
            class="bookmark-btn"
            :class="{ 'bookmark-btn--active': isBookmarked }"
            aria-label="Simpan bookmark"
            @click="$emit('toggle-bookmark', article)"
          >
            {{ isBookmarked ? '♥' : '♡' }}
          </button>
        </div>

        <h1 class="article-title">{{ article.title }}</h1>

        <p class="meta">
          {{ article.author }} · {{ article.published_at }} · 👁 {{ article.visited_count }}
        </p>

        <div class="article-content">
          <!-- TODO: render `article.content` — pastikan sanitasi bila berupa HTML -->
          <p>{{ article.content }}</p>
        </div>

        <div v-if="article.tags?.length" class="tag-list">
          <span v-for="tag in article.tags" :key="tag" class="tag-chip">{{ tag }}</span>
        </div>
      </div>

      <section v-if="related.length" class="related-articles">
        <h2 class="section-title">Artikel Terkait</h2>
        <button
          v-for="post in related"
          :key="post.slug"
          class="article-row"
          @click="$emit('open-article', post.slug)"
        >
          <div class="thumb thumb--sm" />
          <div class="article-row-body">
            <p class="card-title">{{ post.title }}</p>
            <p class="meta">{{ post.author }} · {{ post.published_at }}</p>
          </div>
        </button>
      </section>
    </template>
  </div>
</template>
