<script setup>
defineProps({
  bookmarks: { type: Array, required: true },
})
defineEmits(['open-article', 'toggle-bookmark'])
</script>

<template>
  <div class="page">
    <p v-if="bookmarks.length === 0" class="muted center">Belum ada artikel yang disimpan.</p>

    <div v-for="post in bookmarks" v-else :key="post.slug" class="article-row">
      <button class="article-row-clickable" @click="$emit('open-article', post.slug)">
        <div class="thumb thumb--sm" />
        <div class="article-row-body">
          <span class="category-tag">{{ post.category?.name }}</span>
          <p class="card-title">{{ post.title }}</p>
          <p class="meta">{{ post.author }} · {{ post.published_at }}</p>
        </div>
      </button>
      <button class="remove-btn" aria-label="Hapus dari bookmark" @click="$emit('toggle-bookmark', post)">
        ✕
      </button>
    </div>
  </div>
</template>
