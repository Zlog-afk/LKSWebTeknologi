<script setup>
import { onMounted, ref } from 'vue'
import { getPosts } from '../api/client'

defineEmits(['open-article'])

const breakingNews = ref([])
const recommendations = ref([])
const loading = ref(true)

onMounted(async () => {
  // TODO: ganti `category` di bawah dengan preferensi kategori
  // yang disimpan pengguna di halaman Settings (localStorage).
  try {
    const [breaking, recs] = await Promise.all([
      getPosts({ order_by: 'popular', per_page: 5 }),
      getPosts({ per_page: 10 }),
    ])
    breakingNews.value = breaking.data ?? breaking
    recommendations.value = recs.data ?? recs
  } finally {
    loading.value = false
  }
})
</script>

<template>
  <div class="page">
    <section class="breaking-news">
      <h2 class="section-title">Breaking News</h2>
      <div class="breaking-news-scroller">
        <!-- TODO: terapkan CSS scroll-snap-type: x mandatory pada wrapper ini -->
        <p v-if="loading" class="muted">Memuat...</p>
        <button
          v-for="post in breakingNews"
          :key="post.slug"
          class="breaking-card"
          @click="$emit('open-article', post.slug)"
        >
          <div class="thumb" />
          <p class="card-title">{{ post.title }}</p>
        </button>
      </div>
    </section>

    <section class="recommendations">
      <h2 class="section-title">Rekomendasi Untuk Anda</h2>
      <button
        v-for="post in recommendations"
        :key="post.slug"
        class="article-row"
        @click="$emit('open-article', post.slug)"
      >
        <div class="thumb thumb--sm" />
        <div class="article-row-body">
          <span class="category-tag">{{ post.category?.name }}</span>
          <p class="card-title">{{ post.title }}</p>
          <p class="meta">{{ post.author }} · {{ post.published_at }}</p>
        </div>
      </button>
    </section>
  </div>
</template>
