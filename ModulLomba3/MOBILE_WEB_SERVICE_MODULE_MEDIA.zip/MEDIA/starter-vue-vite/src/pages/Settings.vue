<script setup>
import { onMounted, ref, watch } from 'vue'
import { getCategories } from '../api/client'
import { useTheme } from '../composables/useTheme'

const CATEGORY_PREF_KEY = 'apakabar_category_preference'

const theme = useTheme()
const categories = ref([])
const selected = ref(JSON.parse(localStorage.getItem(CATEGORY_PREF_KEY) || '[]'))

onMounted(async () => {
  const res = await getCategories()
  categories.value = res.data ?? res
})

watch(selected, (value) => {
  localStorage.setItem(CATEGORY_PREF_KEY, JSON.stringify(value))
}, { deep: true })

function toggle(slug) {
  selected.value = selected.value.includes(slug)
    ? selected.value.filter((s) => s !== slug)
    : [...selected.value, slug]
}
</script>

<template>
  <div class="page">
    <section>
      <h2 class="section-title">Theme Mode</h2>
      <div class="theme-options">
        <label v-for="option in ['light', 'dark', 'system']" :key="option" class="radio-row">
          <input type="radio" name="theme" :value="option" v-model="theme" />
          <span style="text-transform: capitalize">{{ option }}</span>
        </label>
      </div>
    </section>

    <section>
      <h2 class="section-title">Category Preference</h2>
      <p class="muted">Dipakai untuk personalisasi Recommendation di Home.</p>
      <div class="checkbox-grid">
        <label v-for="cat in categories" :key="cat.slug" class="checkbox-row">
          <input
            type="checkbox"
            :checked="selected.includes(cat.slug)"
            @change="toggle(cat.slug)"
          />
          <span>{{ cat.name }}</span>
        </label>
      </div>
    </section>

    <section>
      <h2 class="section-title">Offline Mode</h2>
      <p class="muted">
        Saat koneksi hilang, aplikasi akan menampilkan halaman offline
        (lihat file <code>offline/game.html</code> di paket media).
      </p>
    </section>
  </div>
</template>
