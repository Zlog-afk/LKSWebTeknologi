import { createApp } from 'vue'
import App from './App.vue'
import './styles/index.css'

createApp(App).mount('#app')

// Contoh sederhana untuk mendeteksi kehilangan koneksi.
// Peserta bebas mengembangkan pola ini (misal redirect ke /offline/game.html
// atau menampilkan komponen Offline di dalam App).
window.addEventListener('offline', () => {
  console.log('Koneksi terputus — tampilkan halaman offline di sini.')
})
window.addEventListener('online', () => {
  console.log('Koneksi kembali tersambung.')
})
