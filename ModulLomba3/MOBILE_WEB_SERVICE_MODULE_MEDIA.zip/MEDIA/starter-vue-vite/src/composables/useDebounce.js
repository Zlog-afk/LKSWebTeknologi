import { ref, watch } from 'vue'

/**
 * Mengembalikan ref yang sudah di-debounce.
 * Gunakan untuk input pencarian pada halaman Discover
 * agar tidak memanggil API pada setiap ketukan tombol.
 *
 * Contoh: const debouncedSearch = useDebounce(search, 600)
 */
export function useDebounce(source, delayMs = 600) {
  const debounced = ref(source.value)
  let timer = null

  watch(source, (value) => {
    clearTimeout(timer)
    timer = setTimeout(() => {
      debounced.value = value
    }, delayMs)
  })

  return debounced
}
