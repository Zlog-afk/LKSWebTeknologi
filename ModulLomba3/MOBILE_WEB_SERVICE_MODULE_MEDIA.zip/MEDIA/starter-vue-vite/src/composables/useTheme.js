import { ref, watch } from 'vue'

const STORAGE_KEY = 'apakabar_theme' // 'light' | 'dark' | 'system'

function applyTheme(mode) {
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches
  const resolved = mode === 'system' ? (prefersDark ? 'dark' : 'light') : mode
  document.documentElement.setAttribute('data-theme', resolved)
}

/**
 * Kelola preferensi tema (light / dark / system) dan simpan ke localStorage.
 * Dipakai di halaman Settings.
 */
export function useTheme() {
  const mode = ref(localStorage.getItem(STORAGE_KEY) || 'system')

  watch(
    mode,
    (value) => {
      applyTheme(value)
      localStorage.setItem(STORAGE_KEY, value)
    },
    { immediate: true },
  )

  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    if (mode.value === 'system') applyTheme('system')
  })

  return mode
}
