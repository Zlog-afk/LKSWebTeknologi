<script setup>
defineProps({
  title: { type: String, required: true },
  onBack: { type: Function, default: null },
})
</script>

<template>
  <header class="app-header">
    <button v-if="onBack" class="header-back" @click="onBack" aria-label="Kembali">←</button>
    <span v-else class="header-spacer" />
    <h1 class="header-title">{{ title }}</h1>
    <span class="header-spacer" />
  </header>
</template>
