<script setup>
defineProps({
  active: { type: String, required: true },
})
defineEmits(['change'])

const tabs = [
  { key: 'home', label: 'Home', icon: '🏠' },
  { key: 'discover', label: 'Discover', icon: '🔍' },
  { key: 'bookmark', label: 'Bookmark', icon: '🔖' },
  { key: 'settings', label: 'Settings', icon: '⚙️' },
]
</script>

<template>
  <nav class="bottom-nav" aria-label="Navigasi utama">
    <button
      v-for="tab in tabs"
      :key="tab.key"
      class="nav-item"
      :class="{ 'nav-item--active': active === tab.key }"
      :aria-current="active === tab.key ? 'page' : undefined"
      @click="$emit('change', tab.key)"
    >
      <span class="nav-icon" aria-hidden="true">{{ tab.icon }}</span>
      <span class="nav-label">{{ tab.label }}</span>
    </button>
  </nav>
</template>
