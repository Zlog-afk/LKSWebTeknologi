import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './styles/index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)

// Contoh sederhana untuk mendeteksi kehilangan koneksi.
// Peserta bebas mengembangkan pola ini (misal redirect ke /offline/game.html
// atau menampilkan komponen Offline di dalam App).
window.addEventListener('offline', () => {
  console.log('Koneksi terputus — tampilkan halaman offline di sini.')
})
window.addEventListener('online', () => {
  console.log('Koneksi kembali tersambung.')
})
