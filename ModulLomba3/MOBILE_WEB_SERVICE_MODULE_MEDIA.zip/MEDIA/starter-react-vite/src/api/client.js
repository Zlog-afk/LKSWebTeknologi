// Satu-satunya tempat konfigurasi API base URL.
// Jangan hardcode URL API di file lain — selalu import dari sini.
export const API_URL = import.meta.env.VITE_API_URL

async function request(path, { params } = {}) {
  const url = new URL(API_URL + path)
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        url.searchParams.set(key, value)
      }
    })
  }
  const res = await fetch(url.toString())
  if (!res.ok) {
    throw new Error(`Request gagal (${res.status}) untuk ${url.toString()}`)
  }
  return res.json()
}

/**
 * Ambil daftar post dengan dukungan pagination, search, filter kategori & order.
 * @param {Object} query
 * @param {number} [query.page=1]
 * @param {number} [query.per_page=20]
 * @param {'latest'|'popular'} [query.order_by='latest']
 * @param {string} [query.search='']
 * @param {string} [query.category] - slug kategori dipisahkan koma
 */
export function getPosts(query = {}) {
  return request('/api/v1/posts', { params: query })
}

/** Ambil satu post berdasarkan slug. */
export function getPostBySlug(slug) {
  return request(`/api/v1/posts/${slug}`)
}

/** Ambil semua kategori. */
export function getCategories() {
  return request('/api/v1/categories')
}
