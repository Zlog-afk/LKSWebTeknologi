import { useEffect, useState } from 'react'
import Header from './components/Header'
import BottomNav from './components/BottomNav'
import Home from './pages/Home'
import Discover from './pages/Discover'
import ArticleDetail from './pages/ArticleDetail'
import Bookmark from './pages/Bookmark'
import Settings from './pages/Settings'

const BOOKMARK_KEY = 'apakabar_bookmarks'
const TITLES = {
  home: 'ApaKabar',
  discover: 'Discover',
  bookmark: 'Bookmark',
  settings: 'Settings',
}

// NOTE: Ini adalah contoh routing sederhana berbasis state (tanpa library router)
// agar starter tetap ringan. Peserta bebas mengganti dengan react-router
// atau pendekatan lain sesuai preferensi masing-masing.
export default function App() {
  const [activeTab, setActiveTab] = useState('home')
  const [activeSlug, setActiveSlug] = useState(null) // slug artikel yang sedang dibuka
  const [isOffline, setIsOffline] = useState(!navigator.onLine)

  const [bookmarks, setBookmarks] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(BOOKMARK_KEY) || '[]')
    } catch {
      return []
    }
  })

  useEffect(() => {
    localStorage.setItem(BOOKMARK_KEY, JSON.stringify(bookmarks))
  }, [bookmarks])

  useEffect(() => {
    const goOffline = () => setIsOffline(true)
    const goOnline = () => setIsOffline(false)
    window.addEventListener('offline', goOffline)
    window.addEventListener('online', goOnline)
    return () => {
      window.removeEventListener('offline', goOffline)
      window.removeEventListener('online', goOnline)
    }
  }, [])

  function openArticle(slug) {
    setActiveSlug(slug)
  }

  function closeArticle() {
    setActiveSlug(null)
  }

  function toggleBookmark(post) {
    setBookmarks((prev) =>
      prev.some((p) => p.slug === post.slug)
        ? prev.filter((p) => p.slug !== post.slug)
        : [...prev, post],
    )
  }

  if (isOffline) {
    // TODO: peserta dapat mengganti ini dengan <iframe src="/offline/game.html" />
    // atau redirect penuh ke game.html sesuai kebutuhan build tool masing-masing.
    return (
      <div className="offline-screen">
        <p>Anda sedang offline. Silakan buka <code>offline/game.html</code>.</p>
      </div>
    )
  }

  if (activeSlug) {
    return (
      <div className="app-shell">
        <Header title="Detail Artikel" onBack={closeArticle} />
        <main className="app-content">
          <ArticleDetail
            slug={activeSlug}
            onOpenArticle={openArticle}
            isBookmarked={bookmarks.some((p) => p.slug === activeSlug)}
            onToggleBookmark={toggleBookmark}
          />
        </main>
        <BottomNav
          active={activeTab}
          onChange={(tab) => {
            setActiveSlug(null)
            setActiveTab(tab)
          }}
        />
      </div>
    )
  }

  return (
    <div className="app-shell">
      <Header title={TITLES[activeTab]} />
      <main className="app-content">
        {activeTab === 'home' && <Home onOpenArticle={openArticle} />}
        {activeTab === 'discover' && <Discover onOpenArticle={openArticle} />}
        {activeTab === 'bookmark' && (
          <Bookmark
            bookmarks={bookmarks}
            onOpenArticle={openArticle}
            onToggleBookmark={toggleBookmark}
          />
        )}
        {activeTab === 'settings' && <Settings />}
      </main>
      <BottomNav active={activeTab} onChange={setActiveTab} />
    </div>
  )
}
