import { useEffect, useState } from 'react'

/**
 * Mengembalikan nilai yang sudah di-debounce.
 * Gunakan untuk input pencarian pada halaman Discover
 * agar tidak memanggil API pada setiap ketukan tombol.
 *
 * Contoh: const debouncedSearch = useDebounce(search, 600)
 */
export function useDebounce(value, delayMs = 600) {
  const [debounced, setDebounced] = useState(value)

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delayMs)
    return () => clearTimeout(timer)
  }, [value, delayMs])

  return debounced
}
