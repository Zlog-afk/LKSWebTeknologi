const TABS = [
  { key: 'home', label: 'Home', icon: '🏠' },
  { key: 'discover', label: 'Discover', icon: '🔍' },
  { key: 'bookmark', label: 'Bookmark', icon: '🔖' },
  { key: 'settings', label: 'Settings', icon: '⚙️' },
]

export default function BottomNav({ active, onChange }) {
  return (
    <nav className="bottom-nav" aria-label="Navigasi utama">
      {TABS.map((tab) => (
        <button
          key={tab.key}
          className={`nav-item ${active === tab.key ? 'nav-item--active' : ''}`}
          onClick={() => onChange(tab.key)}
          aria-current={active === tab.key ? 'page' : undefined}
        >
          <span className="nav-icon" aria-hidden="true">{tab.icon}</span>
          <span className="nav-label">{tab.label}</span>
        </button>
      ))}
    </nav>
  )
}
