import { useEffect, useState } from 'react'
import { getPostBySlug, getPosts } from '../api/client'

/**
 * Halaman Detail Artikel:
 * - Semua atribut artikel (kategori, judul, tanggal, penulis, views, cover, body, tags)
 * - 3 artikel terkait dari kategori yang sama (exclude artikel ini sendiri)
 * - Tombol bookmark
 */
export default function ArticleDetail({ slug, onOpenArticle, isBookmarked, onToggleBookmark }) {
  const [article, setArticle] = useState(null)
  const [related, setRelated] = useState([])

  useEffect(() => {
    let active = true
    setArticle(null)

    getPostBySlug(slug).then((res) => {
      if (!active) return
      const data = res.data ?? res
      setArticle(data)

      getPosts({ category: data.category?.slug, per_page: 4 }).then((relRes) => {
        if (!active) return
        const list = (relRes.data ?? relRes).filter((p) => p.slug !== slug).slice(0, 3)
        setRelated(list)
      })
    })

    return () => {
      active = false
    }
  }, [slug])

  if (!article) {
    return <div className="page"><p className="muted center">Memuat artikel...</p></div>
  }

  return (
    <div className="page">
      <div className="cover-image" />

      <div className="article-body">
        <div className="article-top-row">
          <span className="category-tag">{article.category?.name}</span>
          <button
            className={`bookmark-btn ${isBookmarked ? 'bookmark-btn--active' : ''}`}
            onClick={() => onToggleBookmark(article)}
            aria-label="Simpan bookmark"
          >
            {isBookmarked ? '♥' : '♡'}
          </button>
        </div>

        <h1 className="article-title">{article.title}</h1>

        <p className="meta">
          {article.author} · {article.published_at} · 👁 {article.visited_count}
        </p>

        <div className="article-content">
          {/* TODO: render `article.content` — pastikan sanitasi bila berupa HTML */}
          <p>{article.content}</p>
        </div>

        {article.tags?.length > 0 && (
          <div className="tag-list">
            {article.tags.map((tag) => (
              <span key={tag} className="tag-chip">{tag}</span>
            ))}
          </div>
        )}
      </div>

      {related.length > 0 && (
        <section className="related-articles">
          <h2 className="section-title">Artikel Terkait</h2>
          {related.map((post) => (
            <button
              key={post.slug}
              className="article-row"
              onClick={() => onOpenArticle(post.slug)}
            >
              <div className="thumb thumb--sm" />
              <div className="article-row-body">
                <p className="card-title">{post.title}</p>
                <p className="meta">{post.author} · {post.published_at}</p>
              </div>
            </button>
          ))}
        </section>
      )}
    </div>
  )
}
