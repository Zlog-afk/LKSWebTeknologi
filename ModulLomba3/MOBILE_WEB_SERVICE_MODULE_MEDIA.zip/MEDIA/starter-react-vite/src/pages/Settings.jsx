import { useEffect, useState } from 'react'
import { getCategories } from '../api/client'
import { useTheme } from '../hooks/useTheme'

const CATEGORY_PREF_KEY = 'apakabar_category_preference'

export default function Settings() {
  const [theme, setTheme] = useTheme()
  const [categories, setCategories] = useState([])
  const [selected, setSelected] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(CATEGORY_PREF_KEY) || '[]')
    } catch {
      return []
    }
  })

  useEffect(() => {
    getCategories().then((res) => setCategories(res.data ?? res))
  }, [])

  useEffect(() => {
    localStorage.setItem(CATEGORY_PREF_KEY, JSON.stringify(selected))
  }, [selected])

  function toggle(slug) {
    setSelected((prev) =>
      prev.includes(slug) ? prev.filter((s) => s !== slug) : [...prev, slug],
    )
  }

  return (
    <div className="page">
      <section>
        <h2 className="section-title">Theme Mode</h2>
        <div className="theme-options">
          {['light', 'dark', 'system'].map((option) => (
            <label key={option} className="radio-row">
              <input
                type="radio"
                name="theme"
                value={option}
                checked={theme === option}
                onChange={() => setTheme(option)}
              />
              <span style={{ textTransform: 'capitalize' }}>{option}</span>
            </label>
          ))}
        </div>
      </section>

      <section>
        <h2 className="section-title">Category Preference</h2>
        <p className="muted">Dipakai untuk personalisasi Recommendation di Home.</p>
        <div className="checkbox-grid">
          {categories.map((cat) => (
            <label key={cat.slug} className="checkbox-row">
              <input
                type="checkbox"
                checked={selected.includes(cat.slug)}
                onChange={() => toggle(cat.slug)}
              />
              <span>{cat.name}</span>
            </label>
          ))}
        </div>
      </section>

      <section>
        <h2 className="section-title">Offline Mode</h2>
        <p className="muted">
          Saat koneksi hilang, aplikasi akan menampilkan halaman offline
          (lihat file <code>offline/game.html</code> di paket media).
        </p>
      </section>
    </div>
  )
}
