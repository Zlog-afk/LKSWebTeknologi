/**
 * Halaman Bookmark: daftar artikel yang disimpan pengguna.
 * `bookmarks` & `onToggleBookmark` dikelola di App.jsx (disimpan ke localStorage)
 * agar bisa diakses juga dari halaman Article Detail dan daftar artikel lainnya.
 */
export default function Bookmark({ bookmarks, onOpenArticle, onToggleBookmark }) {
  if (bookmarks.length === 0) {
    return (
      <div className="page">
        <p className="muted center">Belum ada artikel yang disimpan.</p>
      </div>
    )
  }

  return (
    <div className="page">
      {bookmarks.map((post) => (
        <div key={post.slug} className="article-row">
          <button className="article-row-clickable" onClick={() => onOpenArticle(post.slug)}>
            <div className="thumb thumb--sm" />
            <div className="article-row-body">
              <span className="category-tag">{post.category?.name}</span>
              <p className="card-title">{post.title}</p>
              <p className="meta">{post.author} · {post.published_at}</p>
            </div>
          </button>
          <button
            className="remove-btn"
            onClick={() => onToggleBookmark(post)}
            aria-label="Hapus dari bookmark"
          >
            ✕
          </button>
        </div>
      ))}
    </div>
  )
}
