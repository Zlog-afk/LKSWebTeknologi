import { useCallback, useEffect, useRef, useState } from 'react'
import { getCategories, getPosts } from '../api/client'
import { useDebounce } from '../hooks/useDebounce'

/**
 * Halaman Discover:
 * - Search dengan debounce 0.5–1 detik
 * - Filter kategori (multi-select, dari API)
 * - Infinite scroll (tanpa duplikasi & tanpa data terlewat)
 */
export default function Discover({ onOpenArticle }) {
  const [search, setSearch] = useState('')
  const debouncedSearch = useDebounce(search, 600)

  const [categories, setCategories] = useState([])
  const [selectedCategories, setSelectedCategories] = useState([])

  const [posts, setPosts] = useState([])
  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(true)
  const [loading, setLoading] = useState(false)

  const sentinelRef = useRef(null)

  // Ambil daftar kategori sekali di awal
  useEffect(() => {
    getCategories().then((res) => setCategories(res.data ?? res))
  }, [])

  // Reset ke halaman 1 setiap kali search/filter berubah
  useEffect(() => {
    setPage(1)
    setPosts([])
    setHasMore(true)
  }, [debouncedSearch, selectedCategories])

  // Ambil data setiap kali `page` (atau filter) berubah
  useEffect(() => {
    let active = true
    setLoading(true)

    getPosts({
      page,
      per_page: 10,
      search: debouncedSearch,
      category: selectedCategories.join(','),
    })
      .then((res) => {
        if (!active) return
        const newPosts = res.data ?? res
        setPosts((prev) => (page === 1 ? newPosts : [...prev, ...newPosts]))
        setHasMore(newPosts.length > 0 && (res.meta?.has_more ?? newPosts.length === 10))
      })
      .finally(() => active && setLoading(false))

    return () => {
      active = false
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page])

  // Infinite scroll via IntersectionObserver — hindari trigger ganda saat masih loading
  const handleObserve = useCallback(
    (entries) => {
      const [entry] = entries
      if (entry.isIntersecting && hasMore && !loading) {
        setPage((p) => p + 1)
      }
    },
    [hasMore, loading],
  )

  useEffect(() => {
    const el = sentinelRef.current
    if (!el) return
    const observer = new IntersectionObserver(handleObserve, {
      rootMargin: '200px', // mulai memuat sebelum benar-benar mentok bawah
    })
    observer.observe(el)
    return () => observer.disconnect()
  }, [handleObserve])

  function toggleCategory(slug) {
    setSelectedCategories((prev) =>
      prev.includes(slug) ? prev.filter((c) => c !== slug) : [...prev, slug],
    )
  }

  return (
    <div className="page">
      <div className="search-bar">
        <input
          type="search"
          placeholder="Cari artikel..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="category-chips">
        <button
          className={`chip ${selectedCategories.length === 0 ? 'chip--active' : ''}`}
          onClick={() => setSelectedCategories([])}
        >
          Semua
        </button>
        {categories.map((cat) => (
          <button
            key={cat.slug}
            className={`chip ${selectedCategories.includes(cat.slug) ? 'chip--active' : ''}`}
            onClick={() => toggleCategory(cat.slug)}
          >
            {cat.name}
          </button>
        ))}
      </div>

      <div className="article-grid">
        {posts.map((post) => (
          <button
            key={post.slug}
            className="article-card"
            onClick={() => onOpenArticle(post.slug)}
          >
            <div className="thumb" />
            <span className="category-tag">{post.category?.name}</span>
            <p className="card-title">{post.title}</p>
          </button>
        ))}
      </div>

      {loading && <p className="muted center">Memuat...</p>}
      {!hasMore && posts.length > 0 && (
        <p className="muted center">Semua artikel sudah ditampilkan.</p>
      )}

      {/* Sentinel untuk infinite scroll */}
      <div ref={sentinelRef} style={{ height: 1 }} />
    </div>
  )
}
