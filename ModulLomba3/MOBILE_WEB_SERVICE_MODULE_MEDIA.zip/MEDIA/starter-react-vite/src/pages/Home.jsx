import { useEffect, useState } from 'react'
import { getPosts } from '../api/client'

/**
 * Halaman Home:
 * - Breaking News: daftar horizontal-scroll dengan scroll-snap
 * - Recommendation: daftar artikel berdasarkan kategori pilihan pengguna
 *   (baca preferensi dari localStorage yang disimpan di halaman Settings)
 */
export default function Home({ onOpenArticle }) {
  const [breakingNews, setBreakingNews] = useState([])
  const [recommendations, setRecommendations] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let active = true
    setLoading(true)

    // TODO: ganti `category` di bawah dengan preferensi kategori
    // yang disimpan pengguna di halaman Settings (localStorage).
    Promise.all([
      getPosts({ order_by: 'popular', per_page: 5 }),
      getPosts({ per_page: 10 }),
    ])
      .then(([breaking, recs]) => {
        if (!active) return
        setBreakingNews(breaking.data ?? breaking)
        setRecommendations(recs.data ?? recs)
      })
      .finally(() => active && setLoading(false))

    return () => {
      active = false
    }
  }, [])

  return (
    <div className="page">
      <section className="breaking-news">
        <h2 className="section-title">Breaking News</h2>
        <div className="breaking-news-scroller">
          {/* TODO: terapkan CSS scroll-snap-type: x mandatory pada wrapper ini */}
          {loading && <p className="muted">Memuat...</p>}
          {breakingNews.map((post) => (
            <button
              key={post.slug}
              className="breaking-card"
              onClick={() => onOpenArticle(post.slug)}
            >
              <div className="thumb" />
              <p className="card-title">{post.title}</p>
            </button>
          ))}
        </div>
      </section>

      <section className="recommendations">
        <h2 className="section-title">Rekomendasi Untuk Anda</h2>
        {recommendations.map((post) => (
          <button
            key={post.slug}
            className="article-row"
            onClick={() => onOpenArticle(post.slug)}
          >
            <div className="thumb thumb--sm" />
            <div className="article-row-body">
              <span className="category-tag">{post.category?.name}</span>
              <p className="card-title">{post.title}</p>
              <p className="meta">
                {post.author} · {post.published_at}
              </p>
            </div>
          </button>
        ))}
      </section>
    </div>
  )
}
