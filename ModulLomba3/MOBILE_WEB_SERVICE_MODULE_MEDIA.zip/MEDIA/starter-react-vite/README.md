# Starter — React + Vite (Mobile Web Service Module)

Starter ini **opsional**. Anda boleh menggunakan starter ini, membangun dari nol,
atau memakai starter Vue (`starter-vue-vite`) — pilih salah satu framework saja
sesuai instruksi modul.

## Menjalankan proyek

```bash
npm install
npm run dev
```

## Build untuk pengumpulan

```bash
npm run build
```

Hasil build akan ada di folder `dist/`. Sesuai instruksi modul, salin isi `dist/`
ke dalam folder `XX_MOBILE_WEB_SERVICE_MODULE` agar dapat diakses mulai dari
`index.html`.

## Struktur yang sudah disediakan

```
src/
  api/client.js       -> satu-satunya tempat pemanggilan API (baca VITE_API_URL)
  hooks/useDebounce.js -> debounce untuk search di halaman Discover
  hooks/useTheme.js    -> kelola theme light/dark/system
  components/          -> Header & BottomNav (dipakai di semua halaman)
  pages/                -> Home, Discover, ArticleDetail, Bookmark, Settings
  styles/index.css      -> layout mobile-first (header fixed, nav fixed, max-width 480px)
.env                    -> VITE_API_URL (ganti di sini saja, jangan hardcode di file lain)
public/manifest.json    -> PWA manifest (lengkapi/ganti icon sesuai kebutuhan)
```

## Yang masih perlu Anda kerjakan

Kode di atas adalah **skeleton/starting point**, bukan solusi jadi. Beberapa
bagian ditandai `TODO` dan masih perlu Anda lengkapi, di antaranya:

- Menghubungkan preferensi kategori (Settings) ke query Recommendation di Home
- Menyempurnakan infinite scroll agar tidak lag & tidak ada duplikasi data
- Menyusun halaman offline (arahkan ke `offline/game.html` yang ada di paket media ini)
- Menambahkan ikon PWA yang sesuai (ikon di `public/icons/` saat ini hanya placeholder)
- Menyesuaikan aksesibilitas (label, kontras warna, fokus keyboard) untuk skor Lighthouse
