# PintarMenabung - Frontend (React + Vite + shadcn/ui)

Scaffold frontend untuk **PintarMenabung - Server Module Phase 2 (LKS 2026 WebTech)**.
Dibangun dengan React 18 + Vite + Tailwind CSS + shadcn/ui (Radix primitives) +
react-router-dom + chart.js.

## Cara Pakai

1. Install dependencies:
   ```bash
   npm install
   ```
2. Copy `.env.example` menjadi `.env` dan sesuaikan `VITE_API_URL` dengan URL
   backend Anda (lokal: `http://localhost:8000/api`, saat lomba:
   `http://XX.api-server-module.lksn.id/api`).
3. Jalankan dev server:
   ```bash
   npm run dev
   ```
4. Buka `http://localhost:5173`.

## Struktur Folder

```
src/
├── components/
│   ├── ui/              # Komponen dasar shadcn/ui (Button, Input, Dialog, Select, dst.)
│   ├── dialogs/          # AddWalletDialog, AddTransactionDialog, TransferDialog, ConfirmDialog
│   ├── Navbar.jsx
│   ├── WalletCard.jsx
│   └── TransactionList.jsx
├── context/
│   └── AuthContext.jsx   # State login/register/logout + token di localStorage
├── hooks/
│   └── useShortcuts.js   # Shortcut Alt+W/N/T + Esc, dan hook document.title
├── lib/
│   ├── api.js            # Axios instance (Bearer token otomatis, auto-logout saat 401)
│   └── utils.js          # cn() helper untuk className
├── pages/
│   ├── Register.jsx      # /register
│   ├── Login.jsx         # /login
│   ├── Overview.jsx      # /
│   └── WalletDetail.jsx  # /wallets/:walletId
├── routes/
│   ├── ProtectedRoute.jsx
│   └── GuestRoute.jsx
├── utils/
│   └── format.js         # formatCurrency, formatDate, MONTH_OPTIONS, YEAR_OPTIONS
├── App.jsx
├── main.jsx
└── index.css
```

## Pemetaan Fitur ke Kisi-Kisi

| Ketentuan Kisi-Kisi | Implementasi |
|---|---|
| Document title sesuai halaman | `useDocumentTitle()` di setiap page |
| Logout button di navbar | `Navbar.jsx` |
| Register/Login redirect otomatis | `GuestRoute.jsx` / `ProtectedRoute.jsx` |
| Error spesifik per field | `errors` dari response 422 ditampilkan di bawah masing-masing input |
| Overview: wallet list + saldo | `WalletCard.jsx` + `GET /wallets` |
| Overview: transaksi terbaru, grouped by date | `TransactionList.jsx` (logika `dateKey`) |
| Icon merah/hijau expense/income | `TransactionList.jsx` (`isExpense` check) |
| Format currency "IDR 75.000" | `formatCurrency()` di `utils/format.js` |
| Format tanggal "Jun 7, 2025" | `formatDate()` di `utils/format.js` |
| Add Wallet (tombol "+") | `AddWalletDialog.jsx` |
| Add Transaction | `AddTransactionDialog.jsx` |
| Delete Transaction (double-click + konfirmasi) | `TransactionList` `onDoubleClick` + `ConfirmDialog.jsx` |
| Detail Wallet: filter bulan/tahun (2015-2030) | `MONTH_OPTIONS` / `YEAR_OPTIONS` + `Select` di `WalletDetail.jsx` |
| Doughnut chart ringkasan, label di bawah | `react-chartjs-2` + `plugins.legend.position: 'bottom'` |
| Edit nama wallet (klik, Enter) | `WalletDetail.jsx` (`editingName` state) |
| Hapus wallet (kosongkan + Enter + confirm) | `WalletDetail.jsx` (`handleNameKeyDown`) |
| Add Transaction dengan wallet auto-selected | prop `currentWalletId` diteruskan ke `AddTransactionDialog` |
| Transfer Between Wallets | `TransferDialog.jsx` (lihat catatan di bawah) |
| Shortcut Alt+W / Alt+N / Alt+T / Esc | `useShortcuts()` hook, dipasang di `Overview.jsx` & `WalletDetail.jsx` |

### Catatan Penting: Transfer Between Wallets

Dokumen kisi-kisi Fase 1 **tidak menyediakan endpoint khusus transfer**, dan
instruksi soal melarang penambahan endpoint API baru. Karena seeder data sudah
menyiapkan kategori **"Outgoing Transfer"** (EXPENSE) dan **"Incoming Transfer"**
(INCOME), fitur transfer diimplementasikan sebagai **dua kali panggilan**
`POST /api/transactions` — satu transaksi expense di wallet sumber dan satu
transaksi income di wallet tujuan, dengan jumlah & tanggal yang sama. Lihat
komentar di `TransferDialog.jsx` untuk detail.

### Catatan: Filter Transaksi per Wallet

Endpoint `GET /api/transactions` (D3) hanya mendukung parameter `page`,
`per_page`, `month`, `year` — tidak ada parameter `wallet_id`. Karena itu,
halaman Detail Wallet mengambil seluruh transaksi user (dengan filter
month/year) lalu **memfilter ulang di sisi client** berdasarkan `wallet_id`
yang sesuai dengan halaman aktif.

## Styling / shadcn/ui

Komponen di `src/components/ui/` mengikuti pola resmi shadcn/ui (Radix UI
primitives + `class-variance-authority` + Tailwind), ditulis manual karena
CLI `shadcn` tidak bisa dijalankan di lingkungan sandbox ini (butuh akses ke
registry eksternal). Untuk menambah komponen baru, jalankan di mesin lokal Anda:

```bash
npx shadcn@latest add <nama-komponen>
```

Design token warna ada di `src/index.css` (`:root` CSS variables) dan
`tailwind.config.js` — silakan sesuaikan palet sesuai selera/branding Anda.
