import { Routes, Route } from 'react-router-dom'
import Navbar from '@/components/Navbar'
import ProtectedRoute from '@/routes/ProtectedRoute'
import GuestRoute from '@/routes/GuestRoute'
import Register from '@/pages/Register'
import Login from '@/pages/Login'
import Overview from '@/pages/Overview'
import WalletDetail from '@/pages/WalletDetail'

export default function App() {
  return (
    <div className="min-h-screen bg-secondary/40">
      <Navbar />
      <Routes>
        <Route
          path="/register"
          element={
            <GuestRoute>
              <Register />
            </GuestRoute>
          }
        />
        <Route
          path="/login"
          element={
            <GuestRoute>
              <Login />
            </GuestRoute>
          }
        />
        <Route
          path="/"
          element={
            <ProtectedRoute>
              <Overview />
            </ProtectedRoute>
          }
        />
        <Route
          path="/wallets/:walletId"
          element={
            <ProtectedRoute>
              <WalletDetail />
            </ProtectedRoute>
          }
        />
      </Routes>
    </div>
  )
}
