import { formatCurrency, formatDate, dateKey } from '@/utils/format'

/**
 * Menampilkan daftar transaksi terkelompok per-tanggal.
 * Tanggal hanya ditampilkan sekali per grup (disembunyikan jika sama dengan
 * transaksi sebelumnya), sesuai kisi-kisi halaman Overview & Detail Wallet.
 */
export default function TransactionList({ transactions, showWalletName = true, onDelete }) {
  if (!transactions.length) {
    return <p className="text-sm text-muted-foreground py-6 text-center">Belum ada transaksi.</p>
  }

  let lastDateKey = null

  return (
    <div className="divide-y">
      {transactions.map((tx) => {
        const isExpense = tx.category?.type === 'EXPENSE'
        const currentKey = dateKey(tx.date)
        const showDate = currentKey !== lastDateKey
        lastDateKey = currentKey

        return (
          <div key={tx.id}>
            {showDate && (
              <p className="text-xs font-medium text-muted-foreground pt-4 pb-1 first:pt-0">
                {formatDate(tx.date)}
              </p>
            )}
            <div
              className="flex items-center gap-3 py-2.5 cursor-pointer select-none"
              onDoubleClick={() => onDelete?.(tx)}
              title="Klik dua kali untuk menghapus"
            >
              <div
                className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-base ${
                  isExpense ? 'bg-red-100 text-expense' : 'bg-green-100 text-income'
                }`}
              >
                {tx.category?.icon || (isExpense ? '↑' : '↓')}
              </div>

              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{tx.category?.name}</p>
                <p className="text-xs text-muted-foreground truncate">
                  {showWalletName && tx.wallet?.name}
                  {showWalletName && tx.note ? ' · ' : ''}
                  {tx.note}
                </p>
              </div>

              <p className={`text-sm font-semibold ${isExpense ? 'text-expense' : 'text-income'}`}>
                {isExpense ? '-' : '+'}
                {formatCurrency(tx.amount, tx.wallet?.currency_code)}
              </p>
            </div>
          </div>
        )
      })}
    </div>
  )
}
