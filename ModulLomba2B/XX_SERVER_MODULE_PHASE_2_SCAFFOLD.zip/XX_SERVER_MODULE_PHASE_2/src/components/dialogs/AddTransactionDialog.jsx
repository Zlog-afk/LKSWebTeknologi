import { useEffect, useState } from 'react'
import api from '@/lib/api'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog'
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select'

/**
 * currentWalletId: jika dibuka dari halaman Detail Wallet, field wallet otomatis
 * ter-pilih sesuai wallet yang sedang aktif (sesuai kisi-kisi).
 */
export default function AddTransactionDialog({ open, onOpenChange, wallets, currentWalletId, onCreated }) {
  const [categories, setCategories] = useState([])
  const [form, setForm] = useState({ wallet_id: '', category_id: '', amount: '', date: '', note: '' })
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (open) {
      api.get('/categories').then(({ data }) => setCategories(data.data.categories))
      setForm({
        wallet_id: currentWalletId ? String(currentWalletId) : '',
        category_id: '',
        amount: '',
        date: new Date().toISOString().slice(0, 10),
        note: '',
      })
      setError('')
    }
  }, [open, currentWalletId])

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    setError('')
    try {
      await api.post('/transactions', {
        wallet_id: Number(form.wallet_id),
        category_id: Number(form.category_id),
        amount: Number(form.amount),
        date: form.date,
        note: form.note || undefined,
      })
      onCreated?.()
      onOpenChange(false)
    } catch (err) {
      setError(err.response?.data?.message || 'Gagal menambahkan transaksi.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Tambah Transaksi</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && <p className="text-sm text-destructive">{error}</p>}

          <div className="space-y-1.5">
            <Label>Wallet</Label>
            <Select value={form.wallet_id} onValueChange={(v) => setForm({ ...form, wallet_id: v })}>
              <SelectTrigger>
                <SelectValue placeholder="Pilih wallet" />
              </SelectTrigger>
              <SelectContent>
                {wallets.map((w) => (
                  <SelectItem key={w.id} value={String(w.id)}>
                    {w.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label>Kategori</Label>
            <Select value={form.category_id} onValueChange={(v) => setForm({ ...form, category_id: v })}>
              <SelectTrigger>
                <SelectValue placeholder="Pilih kategori" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((c) => (
                  <SelectItem key={c.id} value={String(c.id)}>
                    {c.icon} {c.name} ({c.type === 'INCOME' ? 'Pemasukan' : 'Pengeluaran'})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="amount">Jumlah</Label>
              <Input
                id="amount"
                type="number"
                min="1"
                value={form.amount}
                onChange={(e) => setForm({ ...form, amount: e.target.value })}
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="date">Tanggal</Label>
              <Input
                id="date"
                type="date"
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="note">Catatan (opsional)</Label>
            <Input id="note" value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} placeholder="mis. starbucks" />
          </div>

          <DialogFooter>
            <Button type="submit" disabled={saving || !form.wallet_id || !form.category_id}>
              {saving ? 'Menyimpan...' : 'Save'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
