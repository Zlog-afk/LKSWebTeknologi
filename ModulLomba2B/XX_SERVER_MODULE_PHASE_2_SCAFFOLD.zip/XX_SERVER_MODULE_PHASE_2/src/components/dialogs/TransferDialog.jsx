import { useEffect, useState } from 'react'
import api from '@/lib/api'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog'
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select'

/**
 * CATATAN IMPLEMENTASI:
 * Dokumen kisi-kisi Fase 1 tidak menyediakan endpoint khusus "transfer", dan
 * instruksi soal MELARANG penambahan endpoint baru. Karena data seed sudah
 * menyediakan kategori "Outgoing Transfer" (EXPENSE) & "Incoming Transfer"
 * (INCOME), transfer antar wallet diimplementasikan sebagai 2 kali panggilan
 * POST /api/transactions: satu transaksi expense di wallet sumber, satu
 * transaksi income di wallet tujuan, dengan amount & tanggal yang sama.
 */
export default function TransferDialog({ open, onOpenChange, wallets, currentWalletId, onCreated }) {
  const [form, setForm] = useState({ from_wallet_id: '', to_wallet_id: '', amount: '', date: '', note: '' })
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (open) {
      setForm({
        from_wallet_id: currentWalletId ? String(currentWalletId) : '',
        to_wallet_id: '',
        amount: '',
        date: new Date().toISOString().slice(0, 10),
        note: '',
      })
      setError('')
    }
  }, [open, currentWalletId])

  async function handleSubmit(e) {
    e.preventDefault()
    if (form.from_wallet_id === form.to_wallet_id) {
      setError('Wallet sumber dan tujuan tidak boleh sama.')
      return
    }

    setSaving(true)
    setError('')
    try {
      const { data } = await api.get('/categories')
      const categories = data.data.categories
      const outgoing = categories.find((c) => c.name === 'Outgoing Transfer')
      const incoming = categories.find((c) => c.name === 'Incoming Transfer')

      if (!outgoing || !incoming) {
        throw new Error('Kategori "Outgoing Transfer" / "Incoming Transfer" tidak ditemukan.')
      }

      await api.post('/transactions', {
        wallet_id: Number(form.from_wallet_id),
        category_id: outgoing.id,
        amount: Number(form.amount),
        date: form.date,
        note: form.note || 'Transfer',
      })
      await api.post('/transactions', {
        wallet_id: Number(form.to_wallet_id),
        category_id: incoming.id,
        amount: Number(form.amount),
        date: form.date,
        note: form.note || 'Transfer',
      })

      onCreated?.()
      onOpenChange(false)
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Gagal melakukan transfer.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Transfer Money</DialogTitle>
          <DialogDescription>Pindahkan dana antar wallet Anda.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && <p className="text-sm text-destructive">{error}</p>}

          <div className="space-y-1.5">
            <Label>Dari Wallet</Label>
            <Select value={form.from_wallet_id} onValueChange={(v) => setForm({ ...form, from_wallet_id: v })}>
              <SelectTrigger>
                <SelectValue placeholder="Pilih wallet sumber" />
              </SelectTrigger>
              <SelectContent>
                {wallets.map((w) => (
                  <SelectItem key={w.id} value={String(w.id)}>
                    {w.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label>Ke Wallet</Label>
            <Select value={form.to_wallet_id} onValueChange={(v) => setForm({ ...form, to_wallet_id: v })}>
              <SelectTrigger>
                <SelectValue placeholder="Pilih wallet tujuan" />
              </SelectTrigger>
              <SelectContent>
                {wallets.filter((w) => String(w.id) !== form.from_wallet_id).map((w) => (
                  <SelectItem key={w.id} value={String(w.id)}>
                    {w.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="transfer-amount">Jumlah</Label>
              <Input
                id="transfer-amount"
                type="number"
                min="1"
                value={form.amount}
                onChange={(e) => setForm({ ...form, amount: e.target.value })}
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="transfer-date">Tanggal</Label>
              <Input
                id="transfer-date"
                type="date"
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
                required
              />
            </div>
          </div>

          <DialogFooter>
            <Button type="submit" disabled={saving || !form.from_wallet_id || !form.to_wallet_id}>
              {saving ? 'Memproses...' : 'Transfer'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
