import { useEffect, useState } from 'react'
import api from '@/lib/api'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog'
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select'

export default function AddWalletDialog({ open, onOpenChange, onCreated }) {
  const [currencies, setCurrencies] = useState([])
  const [name, setName] = useState('')
  const [currencyCode, setCurrencyCode] = useState('')
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (open) {
      api.get('/currencies').then(({ data }) => setCurrencies(data.data.currencies))
      setName('')
      setCurrencyCode('')
      setError('')
    }
  }, [open])

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    setError('')
    try {
      await api.post('/wallets', { name, currency_code: currencyCode })
      onCreated?.()
      onOpenChange(false)
    } catch (err) {
      setError(err.response?.data?.message || 'Gagal menambahkan wallet.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Tambah Wallet</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && <p className="text-sm text-destructive">{error}</p>}

          <div className="space-y-1.5">
            <Label htmlFor="wallet-name">Nama Wallet</Label>
            <Input id="wallet-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Cash IDR" required />
          </div>

          <div className="space-y-1.5">
            <Label>Mata Uang</Label>
            <Select value={currencyCode} onValueChange={setCurrencyCode}>
              <SelectTrigger>
                <SelectValue placeholder="Pilih mata uang" />
              </SelectTrigger>
              <SelectContent>
                {currencies.map((c) => (
                  <SelectItem key={c.code} value={c.code}>
                    {c.code} - {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <DialogFooter>
            <Button type="submit" disabled={saving || !currencyCode}>
              {saving ? 'Menyimpan...' : 'Save'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
