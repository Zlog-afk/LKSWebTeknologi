import { Link } from 'react-router-dom'
import { Card, CardContent } from '@/components/ui/card'
import { formatCurrency } from '@/utils/format'

export default function WalletCard({ wallet }) {
  return (
    <Link to={`/wallets/${wallet.id}`}>
      <Card className="hover:border-primary transition-colors cursor-pointer">
        <CardContent className="p-4">
          <p className="text-sm text-muted-foreground truncate">{wallet.name}</p>
          <p className="text-xl font-semibold mt-1">{formatCurrency(wallet.balance, wallet.currency_code)}</p>
        </CardContent>
      </Card>
    </Link>
  )
}
