import { useEffect } from 'react'

/**
 * Global keyboard shortcuts sesuai kisi-kisi:
 * Alt+W -> Add Wallet, Alt+N -> Add Transaction, Alt+T -> Transfer Money, Esc -> Close form
 */
export function useShortcuts({ onAddWallet, onAddTransaction, onTransfer, onEscape } = {}) {
  useEffect(() => {
    function handleKeyDown(e) {
      if (e.altKey && e.key.toLowerCase() === 'w') {
        e.preventDefault()
        onAddWallet?.()
      } else if (e.altKey && e.key.toLowerCase() === 'n') {
        e.preventDefault()
        onAddTransaction?.()
      } else if (e.altKey && e.key.toLowerCase() === 't') {
        e.preventDefault()
        onTransfer?.()
      } else if (e.key === 'Escape') {
        onEscape?.()
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [onAddWallet, onAddTransaction, onTransfer, onEscape])
}

/** Set document.title sesuai halaman aktif */
export function useDocumentTitle(title) {
  useEffect(() => {
    const prev = document.title
    document.title = title ? `${title} - PintarMenabung` : 'PintarMenabung'
    return () => {
      document.title = prev
    }
  }, [title])
}
