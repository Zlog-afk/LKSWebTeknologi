import { createContext, useContext, useEffect, useState } from 'react'
import api from '@/lib/api'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('user')
    return saved ? JSON.parse(saved) : null
  })
  const [token, setToken] = useState(() => localStorage.getItem('token'))
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (token) localStorage.setItem('token', token)
    else localStorage.removeItem('token')
  }, [token])

  useEffect(() => {
    if (user) localStorage.setItem('user', JSON.stringify(user))
    else localStorage.removeItem('user')
  }, [user])

  async function register({ full_name, email, password }) {
    setLoading(true)
    try {
      const { data } = await api.post('/auth/register', { full_name, email, password })
      setToken(data.data.token)
      setUser({ id: data.data.id, name: data.data.name, email: data.data.email })
      return { success: true }
    } catch (err) {
      return { success: false, errors: err.response?.data?.errors, message: err.response?.data?.message }
    } finally {
      setLoading(false)
    }
  }

  async function login({ email, password }) {
    setLoading(true)
    try {
      const { data } = await api.post('/auth/login', { email, password })
      setToken(data.data.token)
      setUser({ id: data.data.id, name: data.data.name, email: data.data.email })
      return { success: true }
    } catch (err) {
      return { success: false, errors: err.response?.data?.errors, message: err.response?.data?.message }
    } finally {
      setLoading(false)
    }
  }

  async function logout() {
    try {
      await api.post('/auth/logout')
    } catch (_) {
      // abaikan error jaringan saat logout, tetap bersihkan sesi lokal
    } finally {
      setToken(null)
      setUser(null)
    }
  }

  const value = {
    user,
    token,
    isAuthenticated: Boolean(token),
    loading,
    register,
    login,
    logout,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth harus dipakai di dalam <AuthProvider>')
  return ctx
}
