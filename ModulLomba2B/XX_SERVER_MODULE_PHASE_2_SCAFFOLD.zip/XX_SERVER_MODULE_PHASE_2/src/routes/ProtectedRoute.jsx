import { Navigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'

/** Hanya dapat diakses oleh pengguna yang sudah login (Overview & Detail Wallet) */
export default function ProtectedRoute({ children }) {
  const { isAuthenticated } = useAuth()
  if (!isAuthenticated) return <Navigate to="/login" replace />
  return children
}
