import { Navigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'

/** Hanya dapat diakses oleh pengguna yang BELUM login (Register & Login) */
export default function GuestRoute({ children }) {
  const { isAuthenticated } = useAuth()
  if (isAuthenticated) return <Navigate to="/" replace />
  return children
}
