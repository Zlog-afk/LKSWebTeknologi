import { useCallback, useEffect, useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { Doughnut } from 'react-chartjs-2'
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js'
import api from '@/lib/api'
import { useDocumentTitle, useShortcuts } from '@/hooks/useShortcuts'
import { formatCurrency, MONTH_OPTIONS, YEAR_OPTIONS } from '@/utils/format'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select'
import { Card, CardContent } from '@/components/ui/card'
import TransactionList from '@/components/TransactionList'
import AddTransactionDialog from '@/components/dialogs/AddTransactionDialog'
import TransferDialog from '@/components/dialogs/TransferDialog'
import ConfirmDialog from '@/components/dialogs/ConfirmDialog'

ChartJS.register(ArcElement, Tooltip, Legend)

const now = new Date()

export default function WalletDetail() {
  const { walletId } = useParams()
  const navigate = useNavigate()

  const [wallet, setWallet] = useState(null)
  const [wallets, setWallets] = useState([])
  const [transactions, setTransactions] = useState([])
  const [expenseSummary, setExpenseSummary] = useState([])
  const [incomeSummary, setIncomeSummary] = useState([])
  const [loading, setLoading] = useState(true)

  const [month, setMonth] = useState(now.getMonth() + 1)
  const [year, setYear] = useState(now.getFullYear())

  const [editingName, setEditingName] = useState(false)
  const [nameDraft, setNameDraft] = useState('')
  const [deleteWalletConfirm, setDeleteWalletConfirm] = useState(false)

  const [txDialogOpen, setTxDialogOpen] = useState(false)
  const [transferDialogOpen, setTransferDialogOpen] = useState(false)
  const [txToDelete, setTxToDelete] = useState(null)
  const [deleting, setDeleting] = useState(false)

  useDocumentTitle(wallet ? wallet.name : 'Wallet')

  const loadWallet = useCallback(async () => {
    const { data } = await api.get(`/wallets/${walletId}`)
    setWallet(data.data)
    setNameDraft(data.data.name)
  }, [walletId])

  const loadWallets = useCallback(async () => {
    const { data } = await api.get('/wallets')
    setWallets(data.data.wallets)
  }, [])

  const loadTransactions = useCallback(async () => {
    // Endpoint /transactions tidak mendukung filter wallet_id, jadi kita
    // filter transaksi milik wallet ini di sisi client setelah fetch by month/year.
    const { data } = await api.get('/transactions', { params: { month, year, per_page: 100 } })
    setTransactions(data.data.filter((tx) => String(tx.wallet_id) === String(walletId)))
  }, [walletId, month, year])

  const loadReports = useCallback(async () => {
    const [expenseRes, incomeRes] = await Promise.all([
      api.get('/reports/summary-by-category/expense', { params: { month, year } }),
      api.get('/reports/summary-by-category/income', { params: { month, year } }),
    ])
    setExpenseSummary(expenseRes.data.data.summary)
    setIncomeSummary(incomeRes.data.data.summary)
  }, [month, year])

  const loadAll = useCallback(async () => {
    setLoading(true)
    try {
      await Promise.all([loadWallet(), loadWallets(), loadTransactions(), loadReports()])
    } finally {
      setLoading(false)
    }
  }, [loadWallet, loadWallets, loadTransactions, loadReports])

  useEffect(() => {
    loadAll()
  }, [loadAll])

  useShortcuts({
    onAddTransaction: () => setTxDialogOpen(true),
    onTransfer: () => setTransferDialogOpen(true),
    onEscape: () => {
      setTxDialogOpen(false)
      setTransferDialogOpen(false)
      setEditingName(false)
    },
  })

  async function handleNameKeyDown(e) {
    if (e.key !== 'Enter') return

    if (nameDraft.trim() === '') {
      setDeleteWalletConfirm(true)
      return
    }

    if (nameDraft !== wallet.name) {
      await api.put(`/wallets/${walletId}`, { name: nameDraft })
      loadWallet()
    }
    setEditingName(false)
  }

  async function handleDeleteWallet() {
    await api.delete(`/wallets/${walletId}`)
    navigate('/')
  }

  async function handleDeleteTransaction() {
    if (!txToDelete) return
    setDeleting(true)
    try {
      await api.delete(`/transactions/${txToDelete.id}`)
      setTxToDelete(null)
      loadTransactions()
      loadWallet()
    } finally {
      setDeleting(false)
    }
  }

  const chartData = useMemo(() => {
    const combined = [
      ...expenseSummary.map((s) => ({ ...s, color: s.category.color || '#dc2626' })),
      ...incomeSummary.map((s) => ({ ...s, color: s.category.color || '#16a34a' })),
    ]
    return {
      labels: combined.map((s) => s.category.name),
      datasets: [
        {
          data: combined.map((s) => s.amount),
          backgroundColor: combined.map((s) => s.color),
          borderWidth: 0,
        },
      ],
    }
  }, [expenseSummary, incomeSummary])

  const hasSummaryData = expenseSummary.length > 0 || incomeSummary.length > 0

  if (loading && !wallet) {
    return <div className="container py-8 text-sm text-muted-foreground">Memuat wallet...</div>
  }

  if (!wallet) return null

  return (
    <div className="container py-8 space-y-8">
      {/* Wallet header */}
      <div>
        {editingName ? (
          <Input
            autoFocus
            className="text-2xl font-semibold h-auto py-1 max-w-xs"
            value={nameDraft}
            onChange={(e) => setNameDraft(e.target.value)}
            onKeyDown={handleNameKeyDown}
            onBlur={() => setEditingName(false)}
          />
        ) : (
          <h1
            className="text-2xl font-semibold cursor-pointer w-fit"
            onClick={() => setEditingName(true)}
            title="Klik untuk edit nama, kosongkan lalu Enter untuk hapus"
          >
            {wallet.name}
          </h1>
        )}
        <p className="text-3xl font-bold mt-1">{formatCurrency(wallet.balance, wallet.currency_code)}</p>
      </div>

      <div className="flex flex-wrap gap-2">
        <Button onClick={() => setTxDialogOpen(true)}>Add Transaction</Button>
        <Button variant="outline" onClick={() => setTransferDialogOpen(true)}>
          Transfer Money
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Transactions */}
        <div className="lg:col-span-2 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Transaksi</h2>
            <div className="flex gap-2">
              <Select value={String(month)} onValueChange={(v) => setMonth(Number(v))}>
                <SelectTrigger className="w-[130px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {MONTH_OPTIONS.map((m) => (
                    <SelectItem key={m.value} value={String(m.value)}>
                      {m.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={String(year)} onValueChange={(v) => setYear(Number(v))}>
                <SelectTrigger className="w-[100px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {YEAR_OPTIONS.map((y) => (
                    <SelectItem key={y} value={String(y)}>
                      {y}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <Card>
            <CardContent className="p-4">
              <TransactionList transactions={transactions} showWalletName={false} onDelete={setTxToDelete} />
            </CardContent>
          </Card>
        </div>

        {/* Summary chart */}
        <div className="space-y-3">
          <h2 className="text-lg font-semibold">Ringkasan Bulan Ini</h2>
          <Card>
            <CardContent className="p-4">
              {hasSummaryData ? (
                <Doughnut
                  data={chartData}
                  options={{
                    plugins: {
                      legend: { position: 'bottom' },
                    },
                  }}
                />
              ) : (
                <p className="text-sm text-muted-foreground text-center py-8">
                  Belum ada data untuk periode ini.
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <AddTransactionDialog
        open={txDialogOpen}
        onOpenChange={setTxDialogOpen}
        wallets={wallets}
        currentWalletId={walletId}
        onCreated={() => {
          loadTransactions()
          loadWallet()
          loadReports()
        }}
      />
      <TransferDialog
        open={transferDialogOpen}
        onOpenChange={setTransferDialogOpen}
        wallets={wallets}
        currentWalletId={walletId}
        onCreated={() => {
          loadTransactions()
          loadWallet()
          loadReports()
        }}
      />
      <ConfirmDialog
        open={Boolean(txToDelete)}
        onOpenChange={(open) => !open && setTxToDelete(null)}
        title="Hapus transaksi ini?"
        description={txToDelete ? `${txToDelete.category?.name} - ${txToDelete.note || 'tanpa catatan'}` : ''}
        onConfirm={handleDeleteTransaction}
        loading={deleting}
      />
      <ConfirmDialog
        open={deleteWalletConfirm}
        onOpenChange={setDeleteWalletConfirm}
        title={`Hapus wallet "${wallet.name}"?`}
        description="Tindakan ini tidak dapat dibatalkan."
        onConfirm={handleDeleteWallet}
      />
    </div>
  )
}
