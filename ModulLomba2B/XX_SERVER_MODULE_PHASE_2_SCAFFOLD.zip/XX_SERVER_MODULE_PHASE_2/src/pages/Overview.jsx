import { useCallback, useEffect, useState } from 'react'
import { Plus } from 'lucide-react'
import api from '@/lib/api'
import { useDocumentTitle, useShortcuts } from '@/hooks/useShortcuts'
import { Button } from '@/components/ui/button'
import WalletCard from '@/components/WalletCard'
import TransactionList from '@/components/TransactionList'
import AddWalletDialog from '@/components/dialogs/AddWalletDialog'
import AddTransactionDialog from '@/components/dialogs/AddTransactionDialog'
import TransferDialog from '@/components/dialogs/TransferDialog'
import ConfirmDialog from '@/components/dialogs/ConfirmDialog'

export default function Overview() {
  useDocumentTitle('Overview')

  const [wallets, setWallets] = useState([])
  const [transactions, setTransactions] = useState([])
  const [loading, setLoading] = useState(true)

  const [walletDialogOpen, setWalletDialogOpen] = useState(false)
  const [txDialogOpen, setTxDialogOpen] = useState(false)
  const [transferDialogOpen, setTransferDialogOpen] = useState(false)
  const [txToDelete, setTxToDelete] = useState(null)
  const [deleting, setDeleting] = useState(false)

  const loadData = useCallback(async () => {
    setLoading(true)
    try {
      const [walletsRes, txRes] = await Promise.all([
        api.get('/wallets'),
        api.get('/transactions', { params: { per_page: 20 } }),
      ])
      setWallets(walletsRes.data.data.wallets)
      setTransactions(txRes.data.data)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadData()
  }, [loadData])

  useShortcuts({
    onAddWallet: () => setWalletDialogOpen(true),
    onAddTransaction: () => setTxDialogOpen(true),
    onTransfer: () => setTransferDialogOpen(true),
    onEscape: () => {
      setWalletDialogOpen(false)
      setTxDialogOpen(false)
      setTransferDialogOpen(false)
    },
  })

  async function handleDeleteTransaction() {
    if (!txToDelete) return
    setDeleting(true)
    try {
      await api.delete(`/transactions/${txToDelete.id}`)
      setTxToDelete(null)
      loadData()
    } finally {
      setDeleting(false)
    }
  }

  return (
    <div className="container py-8 space-y-8">
      {/* Wallets */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold">Balance</h2>
          <Button size="icon" variant="outline" onClick={() => setWalletDialogOpen(true)} title="Add Wallet (Alt+W)">
            <Plus className="h-4 w-4" />
          </Button>
        </div>

        {loading ? (
          <p className="text-sm text-muted-foreground">Memuat wallet...</p>
        ) : wallets.length === 0 ? (
          <p className="text-sm text-muted-foreground">Belum ada wallet. Klik tombol "+" untuk menambahkan.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {wallets.map((w) => (
              <WalletCard key={w.id} wallet={w} />
            ))}
          </div>
        )}
      </section>

      {/* Transactions */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold">Transaksi Terbaru</h2>
          <Button size="sm" onClick={() => setTxDialogOpen(true)}>
            Add Transaction
          </Button>
        </div>

        {loading ? (
          <p className="text-sm text-muted-foreground">Memuat transaksi...</p>
        ) : (
          <TransactionList transactions={transactions} onDelete={setTxToDelete} />
        )}
      </section>

      <AddWalletDialog open={walletDialogOpen} onOpenChange={setWalletDialogOpen} onCreated={loadData} />
      <AddTransactionDialog
        open={txDialogOpen}
        onOpenChange={setTxDialogOpen}
        wallets={wallets}
        onCreated={loadData}
      />
      <TransferDialog
        open={transferDialogOpen}
        onOpenChange={setTransferDialogOpen}
        wallets={wallets}
        onCreated={loadData}
      />
      <ConfirmDialog
        open={Boolean(txToDelete)}
        onOpenChange={(open) => !open && setTxToDelete(null)}
        title="Hapus transaksi ini?"
        description={txToDelete ? `${txToDelete.category?.name} - ${txToDelete.note || 'tanpa catatan'}` : ''}
        onConfirm={handleDeleteTransaction}
        loading={deleting}
      />
    </div>
  )
}
