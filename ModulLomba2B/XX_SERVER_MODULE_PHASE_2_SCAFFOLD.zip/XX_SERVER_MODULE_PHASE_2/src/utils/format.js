/**
 * Format angka menjadi string currency sesuai contoh di kisi-kisi:
 * formatCurrency(75000, 'IDR') -> "IDR 75.000"
 * formatCurrency(12, 'USD')    -> "USD 12"
 */
export function formatCurrency(amount, currencyCode = 'IDR') {
  const value = Number(amount) || 0
  const formatted = new Intl.NumberFormat('id-ID').format(Math.abs(value))
  return `${currencyCode} ${formatted}`
}

/**
 * Format tanggal jadi human-readable sesuai contoh: "Jun 7, 2025"
 */
export function formatDate(dateStr) {
  const date = new Date(dateStr)
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  })
}

/** Key unik per-hari untuk pengelompokan transaksi (YYYY-MM-DD) */
export function dateKey(dateStr) {
  return new Date(dateStr).toISOString().slice(0, 10)
}

/** Nama bulan untuk dropdown filter di halaman Detail Wallet */
export const MONTH_OPTIONS = [
  { value: 1, label: 'Januari' },
  { value: 2, label: 'Februari' },
  { value: 3, label: 'Maret' },
  { value: 4, label: 'April' },
  { value: 5, label: 'Mei' },
  { value: 6, label: 'Juni' },
  { value: 7, label: 'Juli' },
  { value: 8, label: 'Agustus' },
  { value: 9, label: 'September' },
  { value: 10, label: 'Oktober' },
  { value: 11, label: 'November' },
  { value: 12, label: 'Desember' },
]

/** Rentang tahun 2015 - 2030 sesuai kisi-kisi */
export const YEAR_OPTIONS = Array.from({ length: 2030 - 2015 + 1 }, (_, i) => 2015 + i)
