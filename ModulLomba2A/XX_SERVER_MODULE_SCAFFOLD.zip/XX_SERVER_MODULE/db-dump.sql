-- ============================================================
-- PintarMenabung - Database Dump
-- LKS 2026 WEBTECH - Server Module Phase 1
-- Skema + data contoh (initial schema and sample data)
-- ============================================================

SET FOREIGN_KEY_CHECKS=0;
SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS `pintarmenabung` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `pintarmenabung`;

-- ------------------------------------------------------------
-- Table structure for `users`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- password untuk semua user contoh di bawah: "password123"
INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'Budi', 'budi@webtech.id', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '2025-07-11 16:01:38', '2025-07-11 16:01:38'),
(2, 'Dedi', 'dedi@webtech.id', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '2025-07-11 16:01:46', '2025-07-11 16:01:46');

-- ------------------------------------------------------------
-- Table structure for `currencies`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `currencies`;
CREATE TABLE `currencies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `symbol` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `currencies_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `currencies` (`id`, `name`, `symbol`, `code`, `created_at`, `updated_at`) VALUES
(1, 'US Dollar', '$', 'USD', '2025-07-11 16:01:37', '2025-07-11 16:01:37'),
(2, 'Indonesian Rupiah', 'Rp', 'IDR', '2025-07-11 16:01:37', '2025-07-11 16:01:37'),
(3, 'Euro', '€', 'EUR', '2025-07-11 16:01:37', '2025-07-11 16:01:37'),
(4, 'Singapore Dollar', 'S$', 'SGD', '2025-07-11 16:01:37', '2025-07-11 16:01:37'),
(5, 'Japanese Yen', '¥', 'JPY', '2025-07-11 16:01:37', '2025-07-11 16:01:37');

-- ------------------------------------------------------------
-- Table structure for `categories`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `type` enum('EXPENSE','INCOME') NOT NULL,
  `color` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categories` (`id`, `name`, `icon`, `type`, `color`, `created_at`, `updated_at`) VALUES
(1, 'Outgoing Transfer', '⬆', 'EXPENSE', '#D63031', '2025-07-11 16:01:38', '2025-07-11 16:01:38'),
(2, 'Incoming Transfer', '⬇', 'INCOME', '#00B894', '2025-07-11 16:01:38', '2025-07-11 16:01:38'),
(3, 'Food & Drinks', '🍔', 'EXPENSE', '#E17055', '2025-07-11 16:01:38', '2025-07-11 16:01:38'),
(4, 'Salary', '💰', 'INCOME', '#0984E3', '2025-07-11 16:01:38', '2025-07-11 16:01:38'),
(5, 'Bonus', '🎁', 'INCOME', '#6C5CE7', '2025-07-11 16:01:38', '2025-07-11 16:01:38'),
(6, 'Transportation', '🚗', 'EXPENSE', '#FDCB6E', '2025-07-11 16:01:38', '2025-07-11 16:01:38'),
(7, 'Entertainment', '🎬', 'EXPENSE', '#A29BFE', '2025-07-11 16:01:38', '2025-07-11 16:01:38'),
(8, 'Bills & Utilities', '💡', 'EXPENSE', '#00CEC9', '2025-07-11 16:01:38', '2025-07-11 16:01:38'),
(9, 'Groceries', '🛒', 'EXPENSE', '#55EFC4', '2025-07-28 02:37:46', '2025-07-28 02:37:46');

-- ------------------------------------------------------------
-- Table structure for `wallets`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `wallets`;
CREATE TABLE `wallets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `currency_id` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wallets_user_id_foreign` (`user_id`),
  KEY `wallets_currency_id_foreign` (`currency_id`),
  CONSTRAINT `wallets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wallets_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wallets` (`id`, `user_id`, `currency_id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 2, 'Cash IDR', '2025-07-11 16:01:38', '2025-07-11 16:26:25', NULL),
(2, 1, 2, 'Bank', '2025-07-11 16:01:38', '2025-07-11 16:01:38', NULL),
(3, 2, 1, 'Savings USD', '2025-07-11 16:22:44', '2025-07-11 16:22:44', NULL);

-- ------------------------------------------------------------
-- Table structure for `transactions`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint unsigned NOT NULL,
  `wallet_id` bigint unsigned NOT NULL,
  `amount` bigint unsigned NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_category_id_foreign` (`category_id`),
  KEY `transactions_wallet_id_foreign` (`wallet_id`),
  CONSTRAINT `transactions_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `transactions_wallet_id_foreign` FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `transactions` (`id`, `category_id`, `wallet_id`, `amount`, `note`, `date`, `created_at`, `updated_at`) VALUES
(1, 4, 1, 5000000, 'gaji bulanan', '2025-07-01', '2025-07-01 08:00:00', '2025-07-01 08:00:00'),
(2, 9, 1, 350000, 'belanja bulanan', '2025-07-05', '2025-07-05 10:00:00', '2025-07-05 10:00:00'),
(3, 3, 1, 50000, 'starbucks', '2025-07-31', '2025-07-11 16:44:09', '2025-07-11 16:44:09'),
(4, 6, 1, 100000, 'bensin', '2025-07-10', '2025-07-10 09:00:00', '2025-07-10 09:00:00'),
(5, 5, 2, 1250000, 'bonus proyek', '2025-07-15', '2025-07-15 14:00:00', '2025-07-15 14:00:00'),
(6, 8, 2, 750000, 'listrik & air', '2025-07-20', '2025-07-20 11:00:00', '2025-07-20 11:00:00'),
(7, 4, 3, 2000, 'salary', '2025-07-01', '2025-07-01 08:00:00', '2025-07-01 08:00:00'),
(8, 7, 3, 45, 'movie night', '2025-07-18', '2025-07-18 20:00:00', '2025-07-18 20:00:00');

-- ------------------------------------------------------------
-- Table structure for `personal_access_tokens` (Laravel Sanctum)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS=1;
