<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        User::updateOrCreate([
            'email' => 'john.doe@gmail.com',
        ], [
            'name' => 'john.doe',
            'email' => 'john.doe@gmail.com',
            'password' => Hash::make('Muhammad_570M'),
        ]);
    }
}
