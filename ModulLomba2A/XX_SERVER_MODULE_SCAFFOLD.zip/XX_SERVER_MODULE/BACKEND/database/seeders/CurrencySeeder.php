<?php

namespace Database\Seeders;

use App\Models\Currency;
use Illuminate\Database\Seeder;

class CurrencySeeder extends Seeder
{
    public function run(): void
    {
        $currencies = [
            ['name' => 'Indonesian Rupiah', 'symbol' => 'Rp', 'code' => 'IDR'],
            ['name' => 'US Dollar', 'symbol' => '$', 'code' => 'USD'],
            ['name' => 'Euro', 'symbol' => '€', 'code' => 'EUR'],
            ['name' => 'Singapore Dollar', 'symbol' => 'S$', 'code' => 'SGD'],
            ['name' => 'Japanese Yen', 'symbol' => '¥', 'code' => 'JPY'],
        ];

        foreach ($currencies as $currency) {
            Currency::updateOrCreate(['code' => $currency['code']], $currency);
        }
    }
}
