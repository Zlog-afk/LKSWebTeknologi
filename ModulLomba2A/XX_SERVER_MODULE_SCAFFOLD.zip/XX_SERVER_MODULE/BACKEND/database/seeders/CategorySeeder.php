<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            ['name' => 'Incoming Transfer', 'icon' => '⬇', 'type' => 'INCOME', 'color' => '#00B894'],
            ['name' => 'Salary', 'icon' => '💰', 'type' => 'INCOME', 'color' => '#0984E3'],
            ['name' => 'Bonus', 'icon' => '🎁', 'type' => 'INCOME', 'color' => '#6C5CE7'],
            ['name' => 'Outgoing Transfer', 'icon' => '⬆', 'type' => 'EXPENSE', 'color' => '#D63031'],
            ['name' => 'Food & Drinks', 'icon' => '🍔', 'type' => 'EXPENSE', 'color' => '#E17055'],
            ['name' => 'Groceries', 'icon' => '🛒', 'type' => 'EXPENSE', 'color' => '#55EFC4'],
            ['name' => 'Transportation', 'icon' => '🚗', 'type' => 'EXPENSE', 'color' => '#FDCB6E'],
            ['name' => 'Entertainment', 'icon' => '🎬', 'type' => 'EXPENSE', 'color' => '#A29BFE'],
            ['name' => 'Bills & Utilities', 'icon' => '💡', 'type' => 'EXPENSE', 'color' => '#00CEC9'],
        ];

        foreach ($categories as $category) {
            Category::updateOrCreate(['name' => $category['name']], $category);
        }
    }
}
