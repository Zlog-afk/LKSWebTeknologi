<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Wallet;

class WalletSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $wallets = [
            ['name' => 'Kantong Utama', 'currency_id' => 1, 'user_id' => 1],
        ];

        foreach ($wallets as $w) {
            Wallet::updateOrCreate([
                'name' => $w['name'],
                'currency_id' => $w['currency_id'],
                'user_id' => $w['user_id'],
            ]);
        }
    }
}
