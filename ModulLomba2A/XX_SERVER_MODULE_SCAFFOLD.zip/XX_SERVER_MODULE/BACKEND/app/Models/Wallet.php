<?php

namespace App\Models;

use App\Models\Category;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Wallet extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'user_id',
        'currency_id',
        'name',
    ];

    protected $appends = ['currency_code', 'balance'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function currency()
    {
        return $this->belongsTo(Currency::class);
    }

    public function transactions()
    {
        return $this->hasMany(Transaction::class);
    }

    public function getCurrencyCodeAttribute()
    {
        return $this->currency?->code;
    }

    public function getBalanceAttribute()
    {
        $income = $this->transactions()
            ->whereHas('category', fn ($q) => $q->where('type', Category::TYPE_INCOME))
            ->sum('amount');

        $expense = $this->transactions()
            ->whereHas('category', fn ($q) => $q->where('type', Category::TYPE_EXPENSE))
            ->sum('amount');

        return (int) $income - (int) $expense;
    }
}
