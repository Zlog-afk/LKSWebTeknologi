<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Category;

class CategoryController extends Controller
{
    /**
     * B2: Get All Categories
     * GET /api/categories
     */
    public function index()
    {
        $categories = Category::orderBy('name')->get();

        return response()->json([
            'status' => 'success',
            'message' => 'Get all categories successful',
            'data' => [
                'categories' => $categories,
            ],
        ], 200);
    }
}
