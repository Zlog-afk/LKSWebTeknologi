<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    /**
     * E1: Get Summary by Expense Category
     * GET /api/reports/summary-by-category/expense
     */
    public function summaryByExpenseCategory(Request $request)
    {
        return $this->summaryByType($request, Category::TYPE_EXPENSE, 'Get summary by expense category successful');
    }

    /**
     * E2: Get Summary by Income Category
     * GET /api/reports/summary-by-category/income
     */
    public function summaryByIncomeCategory(Request $request)
    {
        return $this->summaryByType($request, Category::TYPE_INCOME, 'Get summary by income category successful');
    }

    private function summaryByType(Request $request, string $type, string $message)
    {
        $validated = $request->validate([
            'month' => ['nullable', 'integer', 'between:1,12'],
            'year' => ['nullable', 'integer'],
        ]);

        $userId = $request->user()->id;

        $categories = Category::where('type', $type)
            ->with(['transactions' => function ($q) use ($userId, $validated) {
                $q->whereHas('wallet', fn ($w) => $w->where('user_id', $userId))
                    ->when($validated['month'] ?? null, fn ($q2, $m) => $q2->whereMonth('date', $m))
                    ->when($validated['year'] ?? null, fn ($q2, $y) => $q2->whereYear('date', $y));
            }])
            ->get();

        $summary = $categories->map(function ($category) {
            return [
                'category' => $category->makeHidden('transactions'),
                'amount' => (int) $category->transactions->sum('amount'),
            ];
        })->filter(fn ($item) => $item['amount'] > 0)->values();

        return response()->json([
            'status' => 'success',
            'message' => $message,
            'data' => [
                'summary' => $summary,
            ],
        ], 200);
    }
}
