<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Transaction;
use App\Models\Wallet;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
    /**
     * D1: Add Transaction
     * POST /api/transactions
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'wallet_id' => ['required', 'integer', 'exists:wallets,id'],
            'category_id' => ['required', 'integer', 'exists:categories,id'],
            'amount' => ['required', 'integer', 'min:1'],
            'date' => ['required', 'date_format:Y-m-d'],
            'note' => ['nullable', 'string', 'max:255'],
        ]);

        $wallet = Wallet::findOrFail($validated['wallet_id']);

        if ($wallet->user_id !== $request->user()->id) {
            abort(403, 'Forbidden access');
        }

        $transaction = Transaction::create($validated);

        return response()->json([
            'status' => 'success',
            'message' => 'Transaction added successful',
            'data' => [
                'category_id' => $transaction->category_id,
                'wallet_id' => $transaction->wallet_id,
                'amount' => $transaction->amount,
                'note' => $transaction->note,
                'date' => $transaction->date->format('Y-m-d'),
                'updated_at' => $transaction->updated_at,
                'created_at' => $transaction->created_at,
                'id' => $transaction->id,
            ],
        ], 201);
    }

    /**
     * D2: Delete Transaction
     * DELETE /api/transactions/{transactionId}
     */
    public function destroy(Request $request, $transactionId)
    {
        $transaction = Transaction::with('wallet')->findOrFail($transactionId);

        if ($transaction->wallet->user_id !== $request->user()->id) {
            abort(403, 'Forbidden access');
        }

        $transaction->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Transaction deleted successful',
        ], 200);
    }

    /**
     * D3: Get Transactions
     * GET /api/transactions
     */
    public function index(Request $request)
    {
        $validated = $request->validate([
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'min:1'],
            'month' => ['nullable', 'integer', 'between:1,12'],
            'year' => ['nullable', 'integer'],
        ]);

        $perPage = $validated['per_page'] ?? 25;

        $query = Transaction::with(['wallet', 'category'])
            ->whereHas('wallet', fn ($q) => $q->where('user_id', $request->user()->id))
            ->when($validated['month'] ?? null, fn ($q, $month) => $q->whereMonth('date', $month))
            ->when($validated['year'] ?? null, fn ($q, $year) => $q->whereYear('date', $year))
            ->orderByDesc('date');

        $transactions = $query->paginate($perPage);

        return response()->json($transactions, 200);
    }
}
