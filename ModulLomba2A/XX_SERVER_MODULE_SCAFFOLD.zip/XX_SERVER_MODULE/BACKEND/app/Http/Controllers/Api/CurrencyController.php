<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Currency;

class CurrencyController extends Controller
{
    /**
     * B1: Get All Currencies
     * GET /api/currencies
     */
    public function index()
    {
        $currencies = Currency::orderBy('code')->get();

        return response()->json([
            'status' => 'success',
            'message' => 'Get all currencies successful',
            'data' => [
                'currencies' => $currencies,
            ],
        ], 200);
    }
}
