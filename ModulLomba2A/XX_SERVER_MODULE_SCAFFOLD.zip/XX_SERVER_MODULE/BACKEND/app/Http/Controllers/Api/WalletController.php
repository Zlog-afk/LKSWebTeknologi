<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Currency;
use App\Models\Wallet;
use Illuminate\Http\Request;

class WalletController extends Controller
{
    /**
     * C1: Add Wallet
     * POST /api/wallets
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'currency_code' => ['required', 'exists:currencies,code'],
        ]);

        $currency = Currency::where('code', $validated['currency_code'])->firstOrFail();

        $wallet = Wallet::create([
            'user_id' => $request->user()->id,
            'currency_id' => $currency->id,
            'name' => $validated['name'],
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Wallet added successful',
            'data' => [
                'name' => $wallet->name,
                'user_id' => $wallet->user_id,
                'updated_at' => $wallet->updated_at,
                'created_at' => $wallet->created_at,
                'id' => $wallet->id,
                'currency_code' => $wallet->currency_code,
            ],
        ], 201);
    }

    /**
     * C2: Update Wallet
     * PUT /api/wallets/{walletId}
     */
    public function update(Request $request, $walletId)
    {
        $wallet = Wallet::findOrFail($walletId);

        if ($wallet->user_id !== $request->user()->id) {
            abort(403, 'Forbidden access');
        }

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
        ]);

        $wallet->update(['name' => $validated['name']]);

        return response()->json([
            'status' => 'success',
            'message' => 'Wallet updated successful',
            'data' => [
                'id' => $wallet->id,
                'user_id' => $wallet->user_id,
                'name' => $wallet->name,
                'created_at' => $wallet->created_at,
                'updated_at' => $wallet->updated_at,
                'deleted_at' => $wallet->deleted_at,
                'currency_code' => $wallet->currency_code,
            ],
        ], 200);
    }

    /**
     * C3: Delete Wallet
     * DELETE /api/wallets/{walletId}
     */
    public function destroy(Request $request, $walletId)
    {
        $wallet = Wallet::findOrFail($walletId);

        if ($wallet->user_id !== $request->user()->id) {
            abort(403, 'Forbidden access');
        }

        $wallet->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Wallet deleted successful',
        ], 200);
    }

    /**
     * C4: Get All Wallets
     * GET /api/wallets
     */
    public function index(Request $request)
    {
        $wallets = Wallet::where('user_id', $request->user()->id)->get();

        return response()->json([
            'status' => 'success',
            'message' => 'Get all wallets successful',
            'data' => [
                'wallets' => $wallets,
            ],
        ], 200);
    }

    /**
     * C5: Get Detail Wallet
     * GET /api/wallets/{walletId}
     */
    public function show(Request $request, $walletId)
    {
        $wallet = Wallet::findOrFail($walletId);

        if ($wallet->user_id !== $request->user()->id) {
            abort(403, 'Forbidden access');
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Get detail wallet successful',
            'data' => $wallet,
        ], 200);
    }
}
