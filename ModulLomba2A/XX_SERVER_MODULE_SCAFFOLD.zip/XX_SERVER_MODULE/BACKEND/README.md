# PintarMenabung - Backend Scaffolding (Laravel)

Scaffold ini berisi file-file **spesifik aplikasi** (Model, Migration, Seeder,
Controller, Routes, konfigurasi Sanctum & Exception Handler) untuk proyek
**PintarMenabung - Server Module Phase 1 (LKS 2026 WebTech)**.

Folder ini BUKAN instalasi Laravel yang lengkap (tidak ada folder `vendor/`,
`public/`, dsb. — sesuai instruksi soal yang melarang folder tersebut ikut
di-zip). Ikuti langkah di bawah untuk menggabungkannya ke instalasi Laravel
yang baru.

## Cara Pakai

1. Buat project Laravel baru (Laravel 11/12) di folder terpisah:
   ```bash
   composer create-project laravel/laravel pintarmenabung-tmp
   cd pintarmenabung-tmp
   composer require laravel/sanctum
   ```

2. Copy/timpa file-file dari scaffold ini ke project barumu:
   ```
   app/Models/*.php            -> app/Models/
   app/Http/Controllers/Api/   -> app/Http/Controllers/Api/
   app/Http/Controllers/Controller.php -> app/Http/Controllers/Controller.php
   database/migrations/*.php   -> database/migrations/
   database/seeders/*.php      -> database/seeders/
   routes/api.php               -> routes/api.php
   bootstrap/app.php             -> bootstrap/app.php
   config/sanctum.php            -> config/sanctum.php
   .env.example                  -> .env (sesuaikan kredensial DB)
   ```

3. Generate app key & migrasi + seed:
   ```bash
   php artisan key:generate
   php artisan migrate:fresh --seed
   ```

4. Jalankan server:
   ```bash
   php artisan serve
   ```

5. Import `postman/PintarMenabung.postman_collection.json` dan
   `postman/PintarMenabung.postman_environment.json` ke Postman, lalu mulai
   testing dari folder "A. Authentication" (register/login akan otomatis
   menyimpan token ke environment variable `token`).

## Struktur Endpoint

Lihat dokumen kisi-kisi (`02A_Server_Side_Modulen_-_Phase_1_ID.md`) untuk
detail lengkap request/response tiap endpoint. Semua endpoint sudah
diimplementasikan di controller pada folder ini:

- `AuthController`      → register, login, logout
- `CurrencyController`  → get all currencies
- `CategoryController`  → get all categories
- `WalletController`    → CRUD wallet + balance otomatis
- `TransactionController` → CRUD transaksi + pagination & filter month/year
- `ReportController`    → summary by expense/income category

## Catatan Implementasi

- Balance wallet **tidak disimpan** sebagai kolom statis, tapi dihitung
  otomatis (accessor `getBalanceAttribute()` di Model `Wallet`) dari total
  transaksi income dikurangi expense.
- Format response error (401/403/404/422) diseragamkan melalui
  `bootstrap/app.php` (`withExceptions`).
- Field `currency_code` pada wallet adalah accessor yang diturunkan dari
  relasi `currency()` (tabel `currencies`), bukan kolom langsung — sesuai
  ER Diagram yang menyimpan `currency_id` sebagai foreign key.
