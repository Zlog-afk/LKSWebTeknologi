<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\CurrencyController;
use App\Http\Controllers\Api\ReportController;
use App\Http\Controllers\Api\TransactionController;
use App\Http\Controllers\Api\WalletController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| PintarMenabung API Routes
|--------------------------------------------------------------------------
| Sesuai kisi-kisi LKS 2026 WebTech - Server Module Phase 1.
| DILARANG menambahkan endpoint baru di luar yang tercantum di dokumen.
*/

// A. Authentication
Route::post('/auth/register', [AuthController::class, 'register']);
Route::post('/auth/login', [AuthController::class, 'login']);

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/auth/logout', [AuthController::class, 'logout']);

    // B. Currency & Category
    Route::get('/currencies', [CurrencyController::class, 'index']);
    Route::get('/categories', [CategoryController::class, 'index']);

    // C. Wallet
    Route::post('/wallets', [WalletController::class, 'store']);
    Route::put('/wallets/{walletId}', [WalletController::class, 'update']);
    Route::delete('/wallets/{walletId}', [WalletController::class, 'destroy']);
    Route::get('/wallets', [WalletController::class, 'index']);
    Route::get('/wallets/{walletId}', [WalletController::class, 'show']);

    // D. Transaction
    Route::post('/transactions', [TransactionController::class, 'store']);
    Route::delete('/transactions/{transactionId}', [TransactionController::class, 'destroy']);
    Route::get('/transactions', [TransactionController::class, 'index']);

    // E. Financial Report
    Route::get('/reports/summary-by-category/expense', [ReportController::class, 'summaryByExpenseCategory']);
    Route::get('/reports/summary-by-category/income', [ReportController::class, 'summaryByIncomeCategory']);
});
